// Optional: Add any additional interactivity if needed
document.addEventListener("DOMContentLoaded", function () {
  // Example: You can add more animations or handle events here
});
